﻿using System;
using Xamarin.Forms;

namespace ChasedHomeUIDesign.Renderers
{
    public class BorderlessEntry : Entry
    {
    }
}
