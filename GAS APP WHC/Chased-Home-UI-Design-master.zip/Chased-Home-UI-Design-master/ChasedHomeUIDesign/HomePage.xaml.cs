﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace ChasedHomeUIDesign
{
    public partial class HomePage : ContentPage
    {
        public HomePage()
        {
            InitializeComponent();
        }
    }
}
