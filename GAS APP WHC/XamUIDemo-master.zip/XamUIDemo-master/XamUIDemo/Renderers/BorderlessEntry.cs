﻿using Xamarin.Forms;

namespace XamUIDemo.Renderers
{
    public class BorderlessEntry : Entry
    {

    }
}
