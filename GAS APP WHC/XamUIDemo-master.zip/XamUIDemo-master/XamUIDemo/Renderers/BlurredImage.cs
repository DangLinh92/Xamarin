﻿using System;
using Xamarin.Forms;

namespace XamUIDemo.Renderers
{
    public class BlurredImage : Image
    {
    }
}
