﻿using System;
namespace XamUIDemo.Styles
{
    public enum BorderDrawingStyle
    {
        Inside,
        Outside
    }
}
