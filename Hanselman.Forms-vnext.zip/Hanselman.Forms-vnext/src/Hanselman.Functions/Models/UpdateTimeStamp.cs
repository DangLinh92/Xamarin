﻿using System;

namespace Hanselman.Functions.Models
{
    public class UpdateTimeStamp
    {
        public DateTimeOffset LastUpdate { get; set; }
    }
}
