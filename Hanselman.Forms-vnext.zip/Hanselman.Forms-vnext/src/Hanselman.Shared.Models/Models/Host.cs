﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hanselman.Models
{
    public class Host
    {
        public string Name { get; set; }
        public string AvatarUrl { get; set; }
    }
}
