﻿namespace Hanselman.Models
{
    public enum Theme
    {
        Default = 0,
        Light = 1,
        Dark = 2
    }
}
