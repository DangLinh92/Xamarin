﻿
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Hanselman.Views.Twitter
{
    public partial class TweetCell : ViewCell
    {
        public TweetCell()
        {
            InitializeComponent();
        }
    }
}