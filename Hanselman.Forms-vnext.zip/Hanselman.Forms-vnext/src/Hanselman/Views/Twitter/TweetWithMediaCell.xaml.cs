﻿
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Hanselman.Views.Twitter
{
    public partial class TweetWithMediaCell : ViewCell
    {
        public TweetWithMediaCell()
        {
            InitializeComponent();
        }
    }
}