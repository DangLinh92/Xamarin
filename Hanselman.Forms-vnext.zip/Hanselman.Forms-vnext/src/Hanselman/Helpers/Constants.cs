﻿namespace Hanselman.Helpers
{
    public class Constants
    {
        public const string BaseUrl = "https://hanselmanforms.azurewebsites.net/";
        public const string TweetSentimentKey = "pUARdLVszHOr0Mjg9ctXyz/cg67ivZVNyAVuX1nAHyH1Zj6oxvq66g==";
        public const string TweetKey = "/WpNLa4HSav3IGkP7CI1BiQmxbYL73QvBpv4MKedEKYWsjN38oJmZA==";
        public const string BlogKey = "wFcBobtvmNT8hSAHIHvYH6SxMH/v6StaxcWe7nEH5BB4vwZEvEqYKg==";
        public const string PodcastEpisodesKey = "DqLtF37Twr9f8mDagsNeWFk6hxCHwd9BbagpgFxv0oAZwOmEEQ3xtQ==";
        public const string VideoEpisodesKey = "JIZM0s8aSNHg/H9l5szcnjndscpOgOAdFPwvvp/huF/FpHtiNoorsw==";
    }
}
