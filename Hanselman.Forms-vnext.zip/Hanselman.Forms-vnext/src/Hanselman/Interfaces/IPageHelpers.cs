﻿namespace Hanselman.Interfaces
{
    public interface IPageHelpers
    {
        void OnPageVisible();
    }
}
