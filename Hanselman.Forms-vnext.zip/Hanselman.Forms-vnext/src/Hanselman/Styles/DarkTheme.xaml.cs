﻿
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Hanselman.Styles
{
    public partial class DarkTheme : ResourceDictionary
    {
        public DarkTheme()
        {
            InitializeComponent();
        }
    }
}