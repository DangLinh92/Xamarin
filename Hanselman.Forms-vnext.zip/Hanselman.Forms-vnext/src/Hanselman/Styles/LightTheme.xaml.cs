﻿
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Hanselman.Styles
{
    public partial class LightTheme : ResourceDictionary
    {
        public LightTheme()
        {
            InitializeComponent();
        }
    }
}