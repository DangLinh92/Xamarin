﻿using Xamarin.Forms;

namespace Hanselman.Effects
{
    public class RippleEffect : RoutingEffect
    {
        public RippleEffect() : base("Hanselman.RippleEffect")
        {
        }
    }
}
