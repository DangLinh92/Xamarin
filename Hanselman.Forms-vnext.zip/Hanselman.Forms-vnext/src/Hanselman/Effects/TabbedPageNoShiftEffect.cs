﻿using Xamarin.Forms;

namespace Hanselman.Effects
{
    public class TabbedPageNoShiftEffect : RoutingEffect
    {
        public TabbedPageNoShiftEffect() : base($"Hanselman.{nameof(TabbedPageNoShiftEffect)}")
        {
        }
    }
}
