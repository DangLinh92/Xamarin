﻿namespace MvvmHelpers.UnitTests
{
	class UtilTests
	{
	}
}
