﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VehiclesProjectApi.Models
{
    public class RecoverPasswordModel
    {
        public string Email { get; set; }
    }
}
