﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VehiclesProjectApi.Models
{
    public class ChangePhoneModel
    {
        public string Number { get; set; }
    }
}
